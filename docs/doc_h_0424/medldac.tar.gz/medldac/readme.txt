g++ *.cpp svmlight/*.cpp svm_multiclass/*.cpp -o medlda -lm
