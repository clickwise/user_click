pref('extensions.copyurlsexpert.sortby', 'default');
pref('extensions.copyurlsexpert.copyhistory', false);
pref('extensions.copyurlsexpert.toolbaraction', 'active-win');
pref('extensions.copyurlsexpert.opentabdelaystepinmillisecs', 80);
pref('extensions.copyurlsexpert.version', '');
